﻿namespace SportShare
{
    partial class Registrarse
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRegistrarse = new System.Windows.Forms.Button();
            this.txtEnfermedadesRegist = new System.Windows.Forms.TextBox();
            this.txtProvinciaRegist = new System.Windows.Forms.TextBox();
            this.txtPoblaciónRegist = new System.Windows.Forms.TextBox();
            this.txtAlturaRegist = new System.Windows.Forms.TextBox();
            this.txtPesoRegist = new System.Windows.Forms.TextBox();
            this.txtEdadRegist = new System.Windows.Forms.TextBox();
            this.txtTlfRegist = new System.Windows.Forms.TextBox();
            this.txtApellidosRegist = new System.Windows.Forms.TextBox();
            this.txtNombreRegist = new System.Windows.Forms.TextBox();
            this.lblEnfermedadesRegist = new System.Windows.Forms.Label();
            this.lblProvinciaRegist = new System.Windows.Forms.Label();
            this.lblPolaciónRegist = new System.Windows.Forms.Label();
            this.lblAlturaRegist = new System.Windows.Forms.Label();
            this.lblPesoRegist = new System.Windows.Forms.Label();
            this.lblEdadRegist = new System.Windows.Forms.Label();
            this.lblDepPrefRegist = new System.Windows.Forms.Label();
            this.lblApellidosRegist = new System.Windows.Forms.Label();
            this.lblNombreRegist = new System.Windows.Forms.Label();
            this.lblTlfRegist = new System.Windows.Forms.Label();
            this.gbxRegistrarse = new System.Windows.Forms.GroupBox();
            this.dtpFechNac = new System.Windows.Forms.DateTimePicker();
            this.lblFechNac = new System.Windows.Forms.Label();
            this.lblIdUsu = new System.Windows.Forms.Label();
            this.txtIdUsu = new System.Windows.Forms.TextBox();
            this.cbxDeporteCrear = new System.Windows.Forms.ComboBox();
            this.lblContraseñaRegist = new System.Windows.Forms.Label();
            this.txtContraseñaRegist = new System.Windows.Forms.TextBox();
            this.pbxSportShre = new System.Windows.Forms.PictureBox();
            this.txtPeso = new System.Windows.Forms.TextBox();
            this.lblPeso = new System.Windows.Forms.Label();
            this.gbxRegistrarse.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxSportShre)).BeginInit();
            this.SuspendLayout();
            // 
            // btnRegistrarse
            // 
            this.btnRegistrarse.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegistrarse.Location = new System.Drawing.Point(874, 556);
            this.btnRegistrarse.Name = "btnRegistrarse";
            this.btnRegistrarse.Size = new System.Drawing.Size(218, 53);
            this.btnRegistrarse.TabIndex = 122;
            this.btnRegistrarse.Text = "Registrarse";
            this.btnRegistrarse.UseVisualStyleBackColor = true;
            this.btnRegistrarse.Click += new System.EventHandler(this.btnRegistrarse_Click);
            // 
            // txtEnfermedadesRegist
            // 
            this.txtEnfermedadesRegist.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEnfermedadesRegist.Location = new System.Drawing.Point(931, 376);
            this.txtEnfermedadesRegist.Multiline = true;
            this.txtEnfermedadesRegist.Name = "txtEnfermedadesRegist";
            this.txtEnfermedadesRegist.Size = new System.Drawing.Size(272, 69);
            this.txtEnfermedadesRegist.TabIndex = 120;
            // 
            // txtProvinciaRegist
            // 
            this.txtProvinciaRegist.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProvinciaRegist.Location = new System.Drawing.Point(931, 236);
            this.txtProvinciaRegist.Name = "txtProvinciaRegist";
            this.txtProvinciaRegist.Size = new System.Drawing.Size(272, 34);
            this.txtProvinciaRegist.TabIndex = 119;
            // 
            // txtPoblaciónRegist
            // 
            this.txtPoblaciónRegist.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPoblaciónRegist.Location = new System.Drawing.Point(931, 164);
            this.txtPoblaciónRegist.Name = "txtPoblaciónRegist";
            this.txtPoblaciónRegist.Size = new System.Drawing.Size(272, 34);
            this.txtPoblaciónRegist.TabIndex = 118;
            // 
            // txtAlturaRegist
            // 
            this.txtAlturaRegist.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAlturaRegist.Location = new System.Drawing.Point(931, 97);
            this.txtAlturaRegist.Name = "txtAlturaRegist";
            this.txtAlturaRegist.Size = new System.Drawing.Size(161, 34);
            this.txtAlturaRegist.TabIndex = 117;
            // 
            // txtPesoRegist
            // 
            this.txtPesoRegist.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPesoRegist.Location = new System.Drawing.Point(564, 617);
            this.txtPesoRegist.Name = "txtPesoRegist";
            this.txtPesoRegist.Size = new System.Drawing.Size(123, 34);
            this.txtPesoRegist.TabIndex = 116;
            // 
            // txtEdadRegist
            // 
            this.txtEdadRegist.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEdadRegist.Location = new System.Drawing.Point(562, 524);
            this.txtEdadRegist.Name = "txtEdadRegist";
            this.txtEdadRegist.Size = new System.Drawing.Size(123, 34);
            this.txtEdadRegist.TabIndex = 115;
            // 
            // txtTlfRegist
            // 
            this.txtTlfRegist.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTlfRegist.Location = new System.Drawing.Point(277, 449);
            this.txtTlfRegist.Name = "txtTlfRegist";
            this.txtTlfRegist.Size = new System.Drawing.Size(272, 34);
            this.txtTlfRegist.TabIndex = 113;
            // 
            // txtApellidosRegist
            // 
            this.txtApellidosRegist.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtApellidosRegist.Location = new System.Drawing.Point(277, 302);
            this.txtApellidosRegist.Name = "txtApellidosRegist";
            this.txtApellidosRegist.Size = new System.Drawing.Size(272, 34);
            this.txtApellidosRegist.TabIndex = 112;
            // 
            // txtNombreRegist
            // 
            this.txtNombreRegist.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombreRegist.Location = new System.Drawing.Point(277, 236);
            this.txtNombreRegist.Name = "txtNombreRegist";
            this.txtNombreRegist.Size = new System.Drawing.Size(272, 34);
            this.txtNombreRegist.TabIndex = 111;
            // 
            // lblEnfermedadesRegist
            // 
            this.lblEnfermedadesRegist.AutoSize = true;
            this.lblEnfermedadesRegist.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEnfermedadesRegist.Location = new System.Drawing.Point(710, 379);
            this.lblEnfermedadesRegist.Name = "lblEnfermedadesRegist";
            this.lblEnfermedadesRegist.Size = new System.Drawing.Size(190, 29);
            this.lblEnfermedadesRegist.TabIndex = 110;
            this.lblEnfermedadesRegist.Text = "Enfermedades:";
            // 
            // lblProvinciaRegist
            // 
            this.lblProvinciaRegist.AutoSize = true;
            this.lblProvinciaRegist.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProvinciaRegist.Location = new System.Drawing.Point(772, 239);
            this.lblProvinciaRegist.Name = "lblProvinciaRegist";
            this.lblProvinciaRegist.Size = new System.Drawing.Size(128, 29);
            this.lblProvinciaRegist.TabIndex = 109;
            this.lblProvinciaRegist.Text = "Provincia:";
            // 
            // lblPolaciónRegist
            // 
            this.lblPolaciónRegist.AutoSize = true;
            this.lblPolaciónRegist.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPolaciónRegist.Location = new System.Drawing.Point(763, 167);
            this.lblPolaciónRegist.Name = "lblPolaciónRegist";
            this.lblPolaciónRegist.Size = new System.Drawing.Size(137, 29);
            this.lblPolaciónRegist.TabIndex = 108;
            this.lblPolaciónRegist.Text = "Población:";
            // 
            // lblAlturaRegist
            // 
            this.lblAlturaRegist.AutoSize = true;
            this.lblAlturaRegist.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlturaRegist.Location = new System.Drawing.Point(813, 100);
            this.lblAlturaRegist.Name = "lblAlturaRegist";
            this.lblAlturaRegist.Size = new System.Drawing.Size(87, 29);
            this.lblAlturaRegist.TabIndex = 107;
            this.lblAlturaRegist.Text = "Altura:";
            // 
            // lblPesoRegist
            // 
            this.lblPesoRegist.AutoSize = true;
            this.lblPesoRegist.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPesoRegist.Location = new System.Drawing.Point(454, 620);
            this.lblPesoRegist.Name = "lblPesoRegist";
            this.lblPesoRegist.Size = new System.Drawing.Size(80, 29);
            this.lblPesoRegist.TabIndex = 106;
            this.lblPesoRegist.Text = "Peso:";
            // 
            // lblEdadRegist
            // 
            this.lblEdadRegist.AutoSize = true;
            this.lblEdadRegist.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEdadRegist.Location = new System.Drawing.Point(451, 527);
            this.lblEdadRegist.Name = "lblEdadRegist";
            this.lblEdadRegist.Size = new System.Drawing.Size(81, 29);
            this.lblEdadRegist.TabIndex = 105;
            this.lblEdadRegist.Text = "Edad:";
            // 
            // lblDepPrefRegist
            // 
            this.lblDepPrefRegist.AutoSize = true;
            this.lblDepPrefRegist.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDepPrefRegist.Location = new System.Drawing.Point(17, 379);
            this.lblDepPrefRegist.Name = "lblDepPrefRegist";
            this.lblDepPrefRegist.Size = new System.Drawing.Size(230, 29);
            this.lblDepPrefRegist.TabIndex = 103;
            this.lblDepPrefRegist.Text = "Deporte Preferido:";
            // 
            // lblApellidosRegist
            // 
            this.lblApellidosRegist.AutoSize = true;
            this.lblApellidosRegist.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblApellidosRegist.Location = new System.Drawing.Point(117, 305);
            this.lblApellidosRegist.Name = "lblApellidosRegist";
            this.lblApellidosRegist.Size = new System.Drawing.Size(130, 29);
            this.lblApellidosRegist.TabIndex = 104;
            this.lblApellidosRegist.Text = "Apellidos:";
            // 
            // lblNombreRegist
            // 
            this.lblNombreRegist.AutoSize = true;
            this.lblNombreRegist.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombreRegist.Location = new System.Drawing.Point(133, 239);
            this.lblNombreRegist.Name = "lblNombreRegist";
            this.lblNombreRegist.Size = new System.Drawing.Size(114, 29);
            this.lblNombreRegist.TabIndex = 102;
            this.lblNombreRegist.Text = "Nombre:";
            // 
            // lblTlfRegist
            // 
            this.lblTlfRegist.AutoSize = true;
            this.lblTlfRegist.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTlfRegist.Location = new System.Drawing.Point(122, 452);
            this.lblTlfRegist.Name = "lblTlfRegist";
            this.lblTlfRegist.Size = new System.Drawing.Size(125, 29);
            this.lblTlfRegist.TabIndex = 100;
            this.lblTlfRegist.Text = "Teléfono:";
            // 
            // gbxRegistrarse
            // 
            this.gbxRegistrarse.Controls.Add(this.txtPeso);
            this.gbxRegistrarse.Controls.Add(this.lblPeso);
            this.gbxRegistrarse.Controls.Add(this.dtpFechNac);
            this.gbxRegistrarse.Controls.Add(this.lblFechNac);
            this.gbxRegistrarse.Controls.Add(this.lblIdUsu);
            this.gbxRegistrarse.Controls.Add(this.txtIdUsu);
            this.gbxRegistrarse.Controls.Add(this.cbxDeporteCrear);
            this.gbxRegistrarse.Controls.Add(this.lblNombreRegist);
            this.gbxRegistrarse.Controls.Add(this.btnRegistrarse);
            this.gbxRegistrarse.Controls.Add(this.lblTlfRegist);
            this.gbxRegistrarse.Controls.Add(this.txtEnfermedadesRegist);
            this.gbxRegistrarse.Controls.Add(this.txtProvinciaRegist);
            this.gbxRegistrarse.Controls.Add(this.lblContraseñaRegist);
            this.gbxRegistrarse.Controls.Add(this.txtPoblaciónRegist);
            this.gbxRegistrarse.Controls.Add(this.lblApellidosRegist);
            this.gbxRegistrarse.Controls.Add(this.txtAlturaRegist);
            this.gbxRegistrarse.Controls.Add(this.lblDepPrefRegist);
            this.gbxRegistrarse.Controls.Add(this.txtNombreRegist);
            this.gbxRegistrarse.Controls.Add(this.txtApellidosRegist);
            this.gbxRegistrarse.Controls.Add(this.lblEnfermedadesRegist);
            this.gbxRegistrarse.Controls.Add(this.txtTlfRegist);
            this.gbxRegistrarse.Controls.Add(this.lblProvinciaRegist);
            this.gbxRegistrarse.Controls.Add(this.txtContraseñaRegist);
            this.gbxRegistrarse.Controls.Add(this.lblPolaciónRegist);
            this.gbxRegistrarse.Controls.Add(this.lblAlturaRegist);
            this.gbxRegistrarse.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbxRegistrarse.Location = new System.Drawing.Point(392, 212);
            this.gbxRegistrarse.Name = "gbxRegistrarse";
            this.gbxRegistrarse.Size = new System.Drawing.Size(1320, 658);
            this.gbxRegistrarse.TabIndex = 123;
            this.gbxRegistrarse.TabStop = false;
            this.gbxRegistrarse.Text = "Registrarse";
            // 
            // dtpFechNac
            // 
            this.dtpFechNac.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechNac.Location = new System.Drawing.Point(941, 305);
            this.dtpFechNac.Name = "dtpFechNac";
            this.dtpFechNac.Size = new System.Drawing.Size(200, 38);
            this.dtpFechNac.TabIndex = 127;
            // 
            // lblFechNac
            // 
            this.lblFechNac.AutoSize = true;
            this.lblFechNac.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechNac.Location = new System.Drawing.Point(632, 305);
            this.lblFechNac.Name = "lblFechNac";
            this.lblFechNac.Size = new System.Drawing.Size(268, 29);
            this.lblFechNac.TabIndex = 126;
            this.lblFechNac.Text = "Fecha de Nacimiento:";
            // 
            // lblIdUsu
            // 
            this.lblIdUsu.AutoSize = true;
            this.lblIdUsu.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIdUsu.Location = new System.Drawing.Point(108, 100);
            this.lblIdUsu.Name = "lblIdUsu";
            this.lblIdUsu.Size = new System.Drawing.Size(139, 29);
            this.lblIdUsu.TabIndex = 124;
            this.lblIdUsu.Text = "Id Usuario:";
            // 
            // txtIdUsu
            // 
            this.txtIdUsu.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIdUsu.Location = new System.Drawing.Point(277, 97);
            this.txtIdUsu.Name = "txtIdUsu";
            this.txtIdUsu.Size = new System.Drawing.Size(443, 34);
            this.txtIdUsu.TabIndex = 125;
            // 
            // cbxDeporteCrear
            // 
            this.cbxDeporteCrear.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxDeporteCrear.FormattingEnabled = true;
            this.cbxDeporteCrear.Items.AddRange(new object[] {
            "Futbol",
            "Baloncesto",
            "Tenis",
            "Ciclismo",
            "Atletismo",
            "Natación",
            "Padel",
            "Petanca",
            "VoleyBall",
            "Badminton",
            "Hockey",
            "Baseball"});
            this.cbxDeporteCrear.Location = new System.Drawing.Point(277, 376);
            this.cbxDeporteCrear.Name = "cbxDeporteCrear";
            this.cbxDeporteCrear.Size = new System.Drawing.Size(208, 37);
            this.cbxDeporteCrear.TabIndex = 123;
            this.cbxDeporteCrear.Text = "Futbol";
            // 
            // lblContraseñaRegist
            // 
            this.lblContraseñaRegist.AutoSize = true;
            this.lblContraseñaRegist.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContraseñaRegist.Location = new System.Drawing.Point(94, 167);
            this.lblContraseñaRegist.Name = "lblContraseñaRegist";
            this.lblContraseñaRegist.Size = new System.Drawing.Size(153, 29);
            this.lblContraseñaRegist.TabIndex = 101;
            this.lblContraseñaRegist.Text = "Contraseña:";
            // 
            // txtContraseñaRegist
            // 
            this.txtContraseñaRegist.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContraseñaRegist.Location = new System.Drawing.Point(277, 164);
            this.txtContraseñaRegist.Name = "txtContraseñaRegist";
            this.txtContraseñaRegist.Size = new System.Drawing.Size(272, 34);
            this.txtContraseñaRegist.TabIndex = 114;
            this.txtContraseñaRegist.UseSystemPasswordChar = true;
            // 
            // pbxSportShre
            // 
            this.pbxSportShre.Image = global::SportShare.Properties.Resources._1616437656472;
            this.pbxSportShre.Location = new System.Drawing.Point(885, 89);
            this.pbxSportShre.Name = "pbxSportShre";
            this.pbxSportShre.Size = new System.Drawing.Size(407, 63);
            this.pbxSportShre.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxSportShre.TabIndex = 124;
            this.pbxSportShre.TabStop = false;
            // 
            // txtPeso
            // 
            this.txtPeso.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPeso.Location = new System.Drawing.Point(278, 513);
            this.txtPeso.Name = "txtPeso";
            this.txtPeso.Size = new System.Drawing.Size(161, 34);
            this.txtPeso.TabIndex = 129;
            // 
            // lblPeso
            // 
            this.lblPeso.AutoSize = true;
            this.lblPeso.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPeso.Location = new System.Drawing.Point(160, 516);
            this.lblPeso.Name = "lblPeso";
            this.lblPeso.Size = new System.Drawing.Size(80, 29);
            this.lblPeso.TabIndex = 128;
            this.lblPeso.Text = "Peso:";
            // 
            // Registrarse
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1902, 1033);
            this.Controls.Add(this.pbxSportShre);
            this.Controls.Add(this.gbxRegistrarse);
            this.Controls.Add(this.txtPesoRegist);
            this.Controls.Add(this.txtEdadRegist);
            this.Controls.Add(this.lblPesoRegist);
            this.Controls.Add(this.lblEdadRegist);
            this.Name = "Registrarse";
            this.Text = "Registrarse";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.gbxRegistrarse.ResumeLayout(false);
            this.gbxRegistrarse.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxSportShre)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRegistrarse;
        private System.Windows.Forms.TextBox txtEnfermedadesRegist;
        private System.Windows.Forms.TextBox txtProvinciaRegist;
        private System.Windows.Forms.TextBox txtPoblaciónRegist;
        private System.Windows.Forms.TextBox txtAlturaRegist;
        private System.Windows.Forms.TextBox txtPesoRegist;
        private System.Windows.Forms.TextBox txtEdadRegist;
        private System.Windows.Forms.TextBox txtTlfRegist;
        private System.Windows.Forms.TextBox txtApellidosRegist;
        private System.Windows.Forms.TextBox txtNombreRegist;
        private System.Windows.Forms.Label lblEnfermedadesRegist;
        private System.Windows.Forms.Label lblProvinciaRegist;
        private System.Windows.Forms.Label lblPolaciónRegist;
        private System.Windows.Forms.Label lblAlturaRegist;
        private System.Windows.Forms.Label lblPesoRegist;
        private System.Windows.Forms.Label lblEdadRegist;
        private System.Windows.Forms.Label lblDepPrefRegist;
        private System.Windows.Forms.Label lblApellidosRegist;
        private System.Windows.Forms.Label lblNombreRegist;
        private System.Windows.Forms.Label lblTlfRegist;
        private System.Windows.Forms.GroupBox gbxRegistrarse;
        private System.Windows.Forms.PictureBox pbxSportShre;
        private System.Windows.Forms.ComboBox cbxDeporteCrear;
        private System.Windows.Forms.DateTimePicker dtpFechNac;
        private System.Windows.Forms.Label lblFechNac;
        private System.Windows.Forms.Label lblIdUsu;
        private System.Windows.Forms.TextBox txtIdUsu;
        private System.Windows.Forms.Label lblContraseñaRegist;
        private System.Windows.Forms.TextBox txtContraseñaRegist;
        private System.Windows.Forms.TextBox txtPeso;
        private System.Windows.Forms.Label lblPeso;
    }
}